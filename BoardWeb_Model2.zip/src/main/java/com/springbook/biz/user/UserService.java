package com.springbook.biz.user;

public interface UserService {
	
	// CRUD 기능의 메소드 구현
	// 회원 등록
	public UserVO getUser(UserVO vo);
	
	public void insertUser(UserVO vo);

}
