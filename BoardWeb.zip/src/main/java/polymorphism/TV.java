package polymorphism;

public interface TV {
	// 인터페이스의 모든 메서든느 추상 메서드임 (public abstract생략 가능)
	public void powerOn();
	public void powerOff();
	public void volumeUp();
	public void volumeDown();

}
